class Global {
  static int index = 0;
}
