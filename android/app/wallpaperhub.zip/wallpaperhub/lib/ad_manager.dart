import 'dart:io';

class AdManager {

  static String get appId {
    if (Platform.isAndroid) {
      return "<ca-app-pub-8146225151395890~4229280620>";
    } else if (Platform.isIOS) {
      return null;
    } else {
      throw new UnsupportedError("Unsupported platform");
    }
  }

  static String get bannerAdUnitId {
    if (Platform.isAndroid) {
      return "<ca-app-pub-8146225151395890/6663872278";
    } else if (Platform.isIOS) {
      return null;
    } else {
      throw new UnsupportedError("Unsupported platform");
    }
  }

  static String get interstitialAdUnitId {
    if (Platform.isAndroid) {
      return "<ca-app-pub-8146225151395890/6663872278>";
    } else if (Platform.isIOS) {
      return null;
    } else {
      throw new UnsupportedError("Unsupported platform");
    }
  }

  static String get rewardedAdUnitId {
    if (Platform.isAndroid) {
      return "<ca-app-pub-8146225151395890/6663872278>";
    } else if (Platform.isIOS) {
      return null;
    } else {
      throw new UnsupportedError("Unsupported platform");
    }
  }
}